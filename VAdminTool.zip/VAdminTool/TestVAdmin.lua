-- TestVAdmin.lua
-- This file tests the VAdmin system

local VAdminModule = require("VAdmin")
local TestVAdmin = VAdminModule.TestVAdmin

-- Run the test
TestVAdmin()